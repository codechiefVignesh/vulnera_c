#include <iostream>
#include<string.h>

int main() 
{
    int a = 2147483647; // max int
    int b = 1;
    unsigned int u = 0;
    unsigned short us = 3456789;
    short s = 32767;

    // Arithmetic operations
    int result = a + b;  // This should trigger overflow warning for signed int
    unsigned int result2 = u - 1;  // This should trigger underflow warning for unsigned int
    short result3 = s + 1; // This should trigger overflow warning for short
    unsigned short result4 = us + 100; // This should trigger overflow warning for unsigned short

    char arr[10] = "welcome\0";
    int n = strlen(arr);
    // Comparisons
    if (us < u)  // signed and unsigned comparison
    {
        std::cout << "Comparison between signed and unsigned integer.\n";
    }

    // Print statement operations
    std::cout << "Sum: " << a + b << std::endl;  // This should trigger overflow warning in print statement

    // Function call with operations (simulated as binary operation detection)
    int calc = (a + b) * s;  // This should be checked for overflow in function calls

    unsigned short x = 45000;
    unsigned short y = 50000;
    unsigned int z = x*y;
    
    return 0;
}
