#include <iostream>
#include<string.h>

using namespace std;

int main() 
{

    unsigned short x = 45000, y = 50000;
    unsigned z = x * y;
    cout<<z<<endl;
    
    return 0;
}
